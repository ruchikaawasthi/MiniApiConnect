(function() {
    // Create the connector object
    var myConnector = tableau.makeConnector();

    // Define the schema
    myConnector.getSchema = function(schemaCallback) {
        // Schema for magnitude and place data
        var cols = [{
            id: "id",
	    alias: "Employee ID",
            dataType: tableau.dataTypeEnum.string
        },{
            id: "employee_name",
	    alias: "Employee Name",
            dataType: tableau.dataTypeEnum.string
        },{
            id: "employee_salary",
	    alias: "Salary",
            dataType: tableau.dataTypeEnum.float
        },{
            id: "employee_age",
	    alias: "Age",
            dataType: tableau.dataTypeEnum.string
        },{
            id: "profile_image",
	    alias: "Image",
            dataType: tableau.dataTypeEnum.string
        }];

		var tableSchema = {
            id: "sampledara",
            alias: "Sample data",
            columns: cols
        };

        schemaCallback([tableSchema]);
       
       };

    // Download the data
    myConnector.getData = function(table, doneCallback) {
        	apiCall = "http://dummy.restapiexample.com/api/v1/employees";
        $.getJSON(apiCall, function(resp) {
            var feat = resp.data,
                tableData = [];
			// Iterate over the JSON object
            for (var i = 0, len = feat.length; i < len; i++) {
                tableData.push({
                    "id": feat[i].id,
                    "employee_name": feat[i].employee_name,
                    "employee_salary": feat[i].employee_salary,
                    "employee_age": feat[i].employee_age,
                    "profile_image": feat[i].profile_image,
                });
            }
            table.appendRows(tableData);

            doneCallback();
        });
    };

    tableau.registerConnector(myConnector);

    // Create event listeners for when the user submits the form
    $(document).ready(function() {
        $("#submitButton").click(function() {
            tableau.connectionName = "Sample WDC connection"; // This will be the data source name in Tableau
            tableau.submit(); // This sends the connector object to Tableau
        });
    });
})();
